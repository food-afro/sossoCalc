var boutons = document.querySelectorAll('button');
var ecran = document.querySelector('.ecran');
boutons.forEach(function (button) {
    button.addEventListener('click', function () {
        var buttonText = button.textContent || '';
        if (buttonText === '=') {
            try {
                ecran.textContent = eval(ecran.textContent || '');
            }
            catch (error) {
                ecran.textContent = 'Error';
            }
        }
        else if (buttonText === 'Effacer') {
            ecran.textContent = '';
        }
        else {
            ecran.textContent += buttonText;
        }
    });
});
