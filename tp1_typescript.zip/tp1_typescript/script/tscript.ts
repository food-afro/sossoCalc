const boutons: NodeListOf<HTMLButtonElement> = document.querySelectorAll('button');
const ecran: HTMLElement = document.querySelector('.ecran') as HTMLElement;

boutons.forEach((button: HTMLButtonElement) => {
  button.addEventListener('click', () => {
    const buttonText: string = button.textContent || '';  

    if (buttonText === '=') {
      try {
        ecran.textContent = eval(ecran.textContent || ''); 
      } catch (error) {
        ecran.textContent = 'Error';
      }
    } else if (buttonText === 'Effacer') {
      ecran.textContent = '';
    } else {
      ecran.textContent += buttonText;
    }
  });
});
